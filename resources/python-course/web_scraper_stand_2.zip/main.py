from web_scraper import *
from database import *

conn = open_connection()
create_ufo_table_if_not_exists(conn)

months_to_download = get_recorded_months()
print(months_to_download)
for month in months_to_download[:10]:
    extracted_month = extract_month_from_index_entry(month)
    url_format = month_to_url_format(extracted_month)
    all_sights = get_list_of_sightings_in_month(url_format)
    for sight in all_sights:
        save_to_database(conn, sight)

conn.close()