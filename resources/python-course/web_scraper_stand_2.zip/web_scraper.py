from bs4 import BeautifulSoup
import urllib.request as request
import time



def get_html_source(url):
    return request.urlopen(url)


def build_url_for_date(date):
    return "http://www.nuforc.org/webreports/ndxe" + str(date) + ".html"


def all_table_entries_for_date(content):
    soup = BeautifulSoup(content, 'html.parser')
    all_entries = soup.find('table', attrs={"cellspacing": "1"})
    body = all_entries.tbody
    return body.find_all("tr")


def safe_extract_contents(tag):
    if tag.contents and str(tag.contents[0]) != "<br/>":
        return tag.contents[0]


def extract_sight_data_from_entry(entry):
    table_data = entry.find_all("td")
    date = safe_extract_contents(table_data[0].font.a)
    city = safe_extract_contents(table_data[1].font)
    shape = safe_extract_contents(table_data[3].font)
    summary = safe_extract_contents(table_data[5].font)
    return date, city, shape, summary

def get_list_of_sightings_in_month(date):
    url = build_url_for_date(date)
    content = get_html_source(url)
    sightings = []
    for entry in all_table_entries_for_date(content):
        sightings.append(extract_sight_data_from_entry(entry))
    return sightings


def get_index_page_contents():
    return get_html_source("http://www.nuforc.org/webreports/ndxevent.html")

def get_recorded_months():
    content = get_index_page_contents()
    return all_table_entries_for_date(content)

def extract_month_from_index_entry(entry):
    all_columns = entry.find_all("td")
    date = safe_extract_contents(all_columns[0].font.a)
    return date

def month_to_url_format(year_and_month):
    split = year_and_month.split("/") # ["07", "2016"]
    month, year = split
    return year + month

# print(month_to_url_format("07/2016")) # 201607

#print(get_list_of_sightings_in_month("190304"))
#all_months = get_recorded_months()
#for month in all_months:
#    print(extract_month_from_index_entry(month))


# for row in rows:
#    print(extract_sight_data_from_entry(row))
