
for n, i in enumerate(range(10), 1):
    print(n, i)