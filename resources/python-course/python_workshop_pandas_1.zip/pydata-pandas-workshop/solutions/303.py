a = sales_data[sales_data['birthday'] == sales_data['birthday'].max()]
a[a['turnover']==a['turnover'].max()]