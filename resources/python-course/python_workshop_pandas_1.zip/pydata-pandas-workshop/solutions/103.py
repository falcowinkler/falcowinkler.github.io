sales_data.info()
