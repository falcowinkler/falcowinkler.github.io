data2 = pd.read_csv('../data/blooth_sales_data_2.csv')
data2.head()