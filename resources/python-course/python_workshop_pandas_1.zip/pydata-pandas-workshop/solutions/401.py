ax = product_sum.plot.bar(
    title="Summe Verkauf nach Produkt",
    color='green',
    linestyle='--',
    edgecolor='black', 
    linewidth=1.2
)