dataj = pd.read_csv('../data/blooth_sales_data_3.csv', sep=';', decimal=',')
dataj.head()