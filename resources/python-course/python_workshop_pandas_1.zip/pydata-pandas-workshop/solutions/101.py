sales_data.head(7)
