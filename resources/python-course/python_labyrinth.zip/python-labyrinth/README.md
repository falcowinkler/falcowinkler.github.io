# python-for-kids


Some code is from http://usingpython.com/minecraft-2d-program-solution/
